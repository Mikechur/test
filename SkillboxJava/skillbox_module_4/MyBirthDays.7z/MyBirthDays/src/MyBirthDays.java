import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MyBirthDays {
    public static void main(String[] args){
        int age = 0;
        Calendar calendar = Calendar.getInstance();
        Date nowDate = calendar.getTime();
        System.out.println("Текущее время :" + nowDate);

        calendar.set(Calendar.YEAR, 1997);
        calendar.set(Calendar.MONTH, Calendar.MAY);
        calendar.set(Calendar.DAY_OF_MONTH, 16);

        Date firstBDay = calendar.getTime();

        System.out.println("Дата первого дня рождения :" + firstBDay);
        DateFormat dateFormat = new SimpleDateFormat( "dd.MM.YYYY - EEE");
        Date currentBDay = firstBDay;

        while(currentBDay.before(nowDate)){
            String formatted = dateFormat.format(currentBDay);
            System.out.println(age + " - " + formatted);
            calendar.add(Calendar.YEAR, 1);
            currentBDay = calendar.getTime();
            age++;
        }
    }
}
