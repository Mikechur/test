public class Main {
    public static void main(String[] args){

        System.out.println("Byte.MAX_VALUE = " + Byte.MAX_VALUE + "\n" +
                "Byte.MIN_VALUE = " + Byte.MIN_VALUE);
        System.out.println("-------------------------");

        System.out.println("Integer.MAX_VALUE = " + Integer.MAX_VALUE + "\n" +
                "Integer.MIN_VALUE = " + Integer.MIN_VALUE);
        System.out.println("-------------------------");

        System.out.println("Short.MAX_VALUE = " + Short.MAX_VALUE + "\n" +
                "Short.MIN_VALUE = " + Short.MIN_VALUE);
        System.out.println("-------------------------");

        System.out.println("Long.MAX_VALUE = " + Long.MAX_VALUE + "\n" +
                "Long.MIN_VALUE = " + Long.MIN_VALUE);
        System.out.println("-------------------------");

        System.out.println("Float.MAX_VALUE = " + Float.MAX_VALUE + "\n" +
                "Float.MIN_VALUE = " + Float.MIN_VALUE);
        System.out.println("-------------------------");

        System.out.println("Double.MAX_VALUE = " + Double.MAX_VALUE + "\n" +
                "Double.MIN_VALUE = " + Double.MIN_VALUE);
    }
}
